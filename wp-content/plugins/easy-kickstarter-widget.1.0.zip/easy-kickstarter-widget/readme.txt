=== Easy Kickstarter Widget ===
Contributors: MarijnRongen
Tags: Kickstarter, back, project, support, widget
Requires at least: 3.0
Tested up to: 3.1
Stable tag: 1.0
License: GPLv2 or later

This plugin lets you place a Kickstarter widget on your WordPress blog. You can configure the widget by specifying which project you wish to support.

== Description ==

To use the widget just drag it to a sidebar and fill in the url of the Kickstarter project you wish to support. Please note this isn't an official Kickstarter plugin, and I'm not affiliated with Kickstarter in any way.

== Installation ==

Upload the Easy Kickstarter Widget plugin to your blog, activate it and drag the widget to your sidebar.

== Changelog ==

= 1.0 =
* First version