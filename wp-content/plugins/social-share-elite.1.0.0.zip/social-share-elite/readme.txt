=== Social Share Elite ===
Contributors: Rohan Pawale
Plugin Site: http://techlunatic.com
Tags: Facebook like, twitter button, twitter share,buffer button,LinkedIn, Google +1 (plus one) button, Google plus one, Stumbleupon, social share, twitter facebook share, google +1 share
Requires at least: 2.8+
Tested up to: 3.2
Stable tag: 1.0.0

== Description ==
<br />
[Author Site](http://techlunatic.com)|
[Plugin Home Page](http://techlunatic.com/2011/08/social-share-elite-wordpress-plugin/)
<br />
<br />
This plugin is the most efficient way to integrate the important social share buttons like twitter, facebook like, google +1 (plus one), LinkedIn and stumbleupon in three different position and styles.

* Automatically display the social share buttons Above the post, below the post, both above and below or floating left side of post.

* Flat/Round border style with/without background color. All easily configurable through settings.

* Javascript is by default loaded in footer (recommended). This is the most efficient way to load scripts for social share buttons. This will make sure that your site contents are loaded first and the script loading do not interfere with them. Also site loading speed is better by doing so which is an important criteria for SEO. 
Option to load the script in header as well, if you wish to.

* Left side floating option is the latest trend these days. The top and left spacing can be configured according to your site layout. Using simple CSS and not ajax for better performance. Also floating bar can be fixed on that position or absolute and can be configured easily through settings.

* Option to display on home page, static pages, category, tag, archive pages. 

* Shortcode [sse_social_share] which can be inserted in test for any post or pages to display the socail share bar.

* Add a custom field "disable_social_share" with value "yes" to disable social share for specific pages or posts.

* Facebook Like thumbnail will now display thumbnail specific to the post or page.

* Adjust width of individual social share button configure count display.

* Option to manually display the share box at any position.

* Support for buffer app included
== Installation ==

Very easy to install, similar to rest of the plugins.

1. Download and unzip the plugin .zip file.<br />
2. Copy the unzipped folder in your Plugins directory under wordpress installation. (wp-content/plugins)<br />
3. Activate the plugin through the plugin window in the admin panel.<br />
4. Configure the settings through Settings->TWG Social Share in the admin panel.

== Frequently Asked Questions ==

If you have any doubts or question or want to customise the plugin then get in touch with me at 
[SearchTechWord Wordpress Plugin](http://www.techlunatic.com.com/about/)<br />
I will try and help as much as possible and answer all your queries. I am ready to add to more features if you demand for the same, all free of cost. Always there to help you.

== Screenshots ==
You can Check Screen Shots on my website.