<?php
$GLOBALS['wp_tests_options'] = array(
    'active_plugins' => array( 'paypal-donations/paypal-donations.php' ),
    'template'       => 'twentyeleven',
    'stylesheet'     => 'twentyeleven',
);

require_once('D:/Dropbox/Code/_Tools/UniformServer/www/wordpress.dev/wordpress-tests/bootstrap.php');
