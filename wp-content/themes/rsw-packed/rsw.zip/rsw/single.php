<?php
/*
*  Single Page
*/
?>
<?php get_header(); ?>

<?php
get_template_part( 'loop', 'single' );
?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>