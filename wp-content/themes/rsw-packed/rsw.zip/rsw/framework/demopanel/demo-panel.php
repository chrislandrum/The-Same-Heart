<!-- 
**********************************************************************
DEMO Panel code - START
**********************************************************************
-->
<?php
if ( isset( $_GET['demo_themecolor'] ) ) $_SESSION['demo_themecolor']=$_GET['demo_themecolor'];
if ( isset($_SESSION['demo_themecolor'] )) $demo_skin = $_SESSION['demo_themecolor'];

if ( isset( $_GET['demo_skin'] ) ) $_SESSION['demo_skin']=$_GET['demo_skin'];
if ( isset($_SESSION['demo_skin'] )) $demo_skin = $_SESSION['demo_skin'];

if ( isset( $_GET['demo_theme_style'] ) ) $_SESSION['demo_theme_style']=$_GET['demo_theme_style'];
if ( isset($_SESSION['demo_theme_style'] )) $demo_theme_style = $_SESSION['demo_theme_style'];

if ( isset( $_GET['demo_header'] ) ) $_SESSION['demo_header']=$_GET['demo_header'];
if ( isset($_SESSION['demo_header'] )) $demo_header = $_SESSION['demo_header'];

if ( isset( $_GET['demo_header_color'] ) ) $_SESSION['demo_header_color']=$_GET['demo_header_color'];
if ( isset($_SESSION['demo_header_color'] )) $demo_header_color = $_SESSION['demo_header_color'];

if ( isset( $_GET['demo_menu_color'] ) ) $_SESSION['demo_menu_color']=$_GET['demo_menu_color'];
if ( isset($_SESSION['demo_menu_color'] )) $demo_menu_color = $_SESSION['demo_menu_color'];

if ( isset( $_GET['demo_font'] ) ) $_SESSION['demo_font']=$_GET['demo_font'];
if ( isset($_SESSION['demo_font'] )) $heading_font = $_SESSION['demo_font'];

if ( isset( $_GET['demo_title_color'] ) ) $_SESSION['demo_title_color']=$_GET['demo_title_color'];
if ( isset($_SESSION['demo_title_color'] )) $demo_title_color = $_SESSION['demo_title_color'];

if ( isset( $_GET['demo_bg_color'] ) ) $_SESSION['demo_bg_color']=$_GET['demo_bg_color'];
if ( isset($_SESSION['demo_bg_color'] )) $demo_bg_color = $_SESSION['demo_bg_color'];
?>
<div id="demopanel">
	<div class="demo_toggle">
	<img src="<?php echo get_template_directory_uri(); ?>/framework/demopanel/images/open_icon.png" alt="demo toggle" />
	</div>
	
	<div class="paneloptions">
	<span class="demo_light"><a href="?demo_theme_style=light">Light Demo</a></span>
	<span class="demo_dark"><a href="?demo_theme_style=dark">Dark Demo</a></span>
	</div>
</div>
<!-- 
**********************************************************************
DEMO Panel code - END
**********************************************************************
-->
