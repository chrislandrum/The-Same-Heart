<?php
$strings = "tinyMCE.addI18n({en:{
systempanel:{	
desc : 'Theme shortcodes'
}}});
";

?>