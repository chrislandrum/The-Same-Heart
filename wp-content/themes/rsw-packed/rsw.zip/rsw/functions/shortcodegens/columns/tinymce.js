function insertShortcode() {
	
	var shortcodeText;
	var shortcodeId = document.getElementById('column_shortcode').value;
	var sampletext = "Donec tristique augue id convallis rutrum nunc justo egestas magna eu aliquam eros lectus cursus lectus.";
	
	
	if (shortcodeId != 0 && shortcodeId == 'column2' ){
		shortcodeText = "<br />[" + shortcodeId +"]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column2_last' ){
		shortcodeText = "<br />[" + shortcodeId +"]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column3' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column3_last' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
	
	if (shortcodeId != 0 && shortcodeId == 'column32' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column32_last' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column4' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column4_last' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column43' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column43_last' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	
		
	if (shortcodeId != 0 && shortcodeId == 'column5' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column5_last' ){
		shortcodeText = "<br />[" + shortcodeId +"]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column52' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column52_last' ){
		shortcodeText = "<br />[" + shortcodeId +"]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column53' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column53_last' ){
		shortcodeText = "<br />[" + shortcodeId +"]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
	if (shortcodeId != 0 && shortcodeId == 'column6' ){
		shortcodeText = "<br />[" + shortcodeId + "]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'column6_last' ){
		shortcodeText = "<br />[" + shortcodeId +"]<br />" + sampletext + "<br />[/" + shortcodeId +"]<br />";	
		}
	
		
	if (shortcodeId != 0 && shortcodeId == 'two_column_grid' ){
		shortcodeText = "[column2]<br />" + sampletext + "<br />[/column2]<br /><br />[column2_last]<br />" + sampletext + "<br />[/column2_last]";	
		}
	
	if (shortcodeId != 0 && shortcodeId == 'three_column_grid' ){
		shortcodeText = "[column3]<br />" + sampletext + "<br />[/column3]<br /><br />[column3]<br />" + sampletext + "<br />[/column3]<br /><br />[column3_last]<br />" + sampletext + "<br />[/column3_last]";	
		}
		
	if (shortcodeId != 0 && shortcodeId == 'four_column_grid' ){
		shortcodeText = "[column4]<br />" + sampletext + "<br />[/column4]<br /><br />[column4]<br />" + sampletext + "<br />[/column4]<br /><br />[column4]<br />" + sampletext + "<br />[/column4]<br /><br />[column4_last]<br />" + sampletext + "<br />[/column4_last]";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'five_column_grid' ){
		shortcodeText = "[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5_last]<br />" + sampletext + "<br />[/column5_last]";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'six_column_grid' ){
		shortcodeText = "[column6]<br />" + sampletext + "<br />[/column6]<br /><br />[column6]<br />" + sampletext + "<br />[/column6]<br /><br />[column6]<br />" + sampletext + "<br />[/column6]<br /><br />[column6]<br />" + sampletext + "<br />[/column6]<br /><br />[column6]<br />" + sampletext + "<br />[/column6]<br /><br />[column6_last]<br />" + sampletext + "<br />[/column6_last]";	
		}
		
		
		
		// Mixed grid layouts
		
		// 3 column grid
		
		if (shortcodeId != 0 && shortcodeId == 'onethird_twothird' ){
		shortcodeText = "<br />[column3]<br />" + sampletext + "<br />[/column3]<br /><br />[column32_last]<br />" + sampletext + "<br />[/column32_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'twothird_onethird' ){
		shortcodeText = "<br />[column32]<br />" + sampletext + "<br />[/column32]<br /><br />[column3_last]<br />" + sampletext + "<br />[/column3_last]<br />";	
		}
		
		// 4 column grid
		if (shortcodeId != 0 && shortcodeId == 'onefourth_onefourth_half' ){
		shortcodeText = "<br />[column4]<br />" + sampletext + "<br />[/column4]<br /><br />[column4]<br />" + sampletext + "<br />[/column4]<br /><br />[column2_last]<br />" + sampletext + "<br />[/column2_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'onefourth_half_onefourth' ){
		shortcodeText = "<br />[column4]<br />" + sampletext + "<br />[/column4]<br /><br />[column2]<br />" + sampletext + "<br />[/column2]<br /><br />[column4_last]<br />" + sampletext + "<br />[/column4_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'half_onefourth_onefourth' ){
			shortcodeText = "<br />[column2]<br />" + sampletext + "<br />[/column2]<br /><br />[column4]<br />" + sampletext + "<br />[/column4]<br /><br />[column4_last]<br />" + sampletext + "<br />[/column4_last]<br />";	
		}
		
		
		if (shortcodeId != 0 && shortcodeId == 'threefourth_onefourth' ){
			shortcodeText = "<br />[column43]<br />" + sampletext + "<br />[/column43]<br /><br />[column4_last]<br />" + sampletext + "<br />[/column4_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'onefourth_threefourth' ){
			shortcodeText = "<br />[column4]<br />" + sampletext + "<br />[/column4]<br /><br />[column43_last]<br />" + sampletext + "<br />[/column43_last]<br />";	
		}
		
		// 5 columns grids
		
		if (shortcodeId != 0 && shortcodeId == 'twofifth_threefifth' ){
			shortcodeText = "<br />[column52]<br />" + sampletext + "<br />[/column52]<br /><br />[column53_last]<br />" + sampletext + "<br />[/column53_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'threefifth_twofifth' ){
			shortcodeText = "<br />[column53]<br />" + sampletext + "<br />[/column53]<br /><br />[column52_last]<br />" + sampletext + "<br />[/column52_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'onefifth_onefifth_onefifth_twofifth' ){
			shortcodeText = "<br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column52_last]<br />" + sampletext + "<br />[/column52_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'onefifth_onefifth_twofifth_onefifth' ){
			shortcodeText = "<br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column52]<br />" + sampletext + "<br />[/column52]<br /><br />[column5_last]<br />" + sampletext + "<br />[/column5_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'onefifth_twofifth_onefifth_onefifth' ){
			shortcodeText = "<br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column52]<br />" + sampletext + "<br />[/column52]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5_last]<br />" + sampletext + "<br />[/column5_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'twofifth_onefifth_onefifth_onefifth' ){
			shortcodeText = "<br />[column52]<br />" + sampletext + "<br />[/column52]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5_last]<br />" + sampletext + "<br />[/column5_last]<br />";	
		}
		
		
		
		if (shortcodeId != 0 && shortcodeId == 'onefifth_twofifth_twofifth' ){
			shortcodeText = "<br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column52]<br />" + sampletext + "<br />[/column52]<br /><br />[column52_last]<br />" + sampletext + "<br />[/column52_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'twofifth_onefifth_twofifth' ){
			shortcodeText = "<br />[column52]<br />" + sampletext + "<br />[/column52]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column52_last]<br />" + sampletext + "<br />[/column52_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'twofifth_twofifth_onefifth' ){
			shortcodeText = "<br />[column52]<br />" + sampletext + "<br />[/column52]<br /><br />[column52]<br />" + sampletext + "<br />[/column52]<br /><br />[column5_last]<br />" + sampletext + "<br />[/column5_last]<br />";	
		}
		
		
		if (shortcodeId != 0 && shortcodeId == 'onefifth_onefifth_threefifth' ){
			shortcodeText = "<br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column53_last]<br />" + sampletext + "<br />[/column53_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'onefifth_threefifth_onefifth' ){
			shortcodeText = "<br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column53]<br />" + sampletext + "<br />[/column53]<br /><br />[column5_last]<br />" + sampletext + "<br />[/column5_last]<br />";	
		}
		
		if (shortcodeId != 0 && shortcodeId == 'threefifth_onefifth_onefifth' ){
			shortcodeText = "<br />[column53]<br />" + sampletext + "<br />[/column53]<br /><br />[column5]<br />" + sampletext + "<br />[/column5]<br /><br />[column5_last]<br />" + sampletext + "<br />[/column5_last]<br />";	
		}
		
		
	if ( shortcodeId == 0 ){
			tinyMCEPopup.close();
		}	
	
	if(window.tinyMCE) {
		//TODO: For QTranslate we should use here 'qtrans_textarea_content' instead 'content'
		window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, shortcodeText);
		//Peforms a clean up of the current editor HTML. 
		//tinyMCEPopup.editor.execCommand('mceCleanup');
		//Repaints the editor. Sometimes the browser has graphic glitches. 
		tinyMCEPopup.editor.execCommand('mceRepaint');
		tinyMCEPopup.close();
	}
	return;
}
