<div class="pagination clearfix">
   <!-- REMOVE default page navigation once your custom pagination is working. -->
   <?php //REMOVE DEFAULT:  next_posts_link('&laquo;&laquo; Older Posts')
        //REMOVE DEFAULT:   previous_posts_link('Newer Posts &raquo;&raquo;') ?>
 
   <!-- ADD Custom Numbered Pagination code. -->
   <?php if(function_exists('pagenavi')) { pagenavi(); } ?>
</div>