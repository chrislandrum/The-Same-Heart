<ul id="menu-top" class="menu">
<li><a href="<?php echo home_url(); ?>">
<strong>Menu</strong>
<span>You can use WP menu builder to build menus</span></a>
</li>
</ul>