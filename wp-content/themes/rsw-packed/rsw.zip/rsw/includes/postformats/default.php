<div class="entry-post-wrapper">

<?php
	get_template_part( 'includes/postformats/post-contents' );
	get_template_part( 'includes/postformats/post-data' );
?>

</div>