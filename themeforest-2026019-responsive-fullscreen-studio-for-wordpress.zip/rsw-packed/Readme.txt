RSW for WordPress Readme
-------------------------------------------

Installation
------------

Extract the file in the rsw-packed.zip

Inside the extracts of the packed file you'll find the rsw.zip file.

You can upload the rsw.zip file to the wordpress theme folder via WP-Admin.

Please follow

http://codex.wordpress.org/Using_Themes#Adding_New_Themes

or

Please read the Help Guide for instructions on installing the theme using FTP ( Recommended Method of upload )

Thank you for purchasing rsw for WordPress.

imaginem